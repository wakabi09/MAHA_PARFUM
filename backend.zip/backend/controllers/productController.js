import Product from '../models/productModel.js';

export const getAllProducts = async (req, res) => {
  try {
    const products = await Product.find(); // ✅ findAll → find
    res.json(products);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const getProductById = async (req, res) => {
  try {
    const product = await Product.findById(req.params.id); // ✅ findByPk → findById
    if (!product) return res.status(404).json({ message: 'Product not found' });
    res.json(product);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const createProduct = async (req, res) => {
  const { name, image, brand, description, price, countInStock, notes } = req.body;
  try {
    const newProduct = new Product({
      name,
      image,
      brand,
      description,
      price,
      countInStock,
      notes
    });
    await newProduct.save(); // ✅ .create → new + .save
    res.status(201).json(newProduct);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

export const updateProduct = async (req, res) => {
  const { name, image, brand, description, price, countInStock, notes } = req.body;
  try {
    const product = await Product.findById(req.params.id); // ✅ findByPk → findById
    if (!product) return res.status(404).json({ message: 'Product not found' });

    product.name = name;
    product.image = image;
    product.brand = brand;
    product.description = description;
    product.price = price;
    product.countInStock = countInStock;
    product.notes = notes;

    await product.save(); // ✅ save after modifying fields
    res.json(product);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

export const deleteProduct = async (req, res) => {
  try {
    const product = await Product.findByIdAndDelete(req.params.id); // ✅ shortcut: findByIdAndDelete
    if (!product) return res.status(404).json({ message: 'Product not found' });
    res.json({ message: 'Product deleted' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
