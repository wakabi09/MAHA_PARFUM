import express from 'express';
import { protect, authorize } from '../middleware/authMiddleware.js';

const router = express.Router();

router.get(
  '/dashboard',
  protect, // Cek token JWT dan set req.user
  authorize('admin', 'owner'), // Hanya role admin & owner yang boleh akses
  (req, res) => {
    res.json({ message: 'Selamat datang di dashboard admin' });
  }
);

export default router;
